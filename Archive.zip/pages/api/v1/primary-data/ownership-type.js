import prisma from "../../../../prisma/MyPrismaClient";

const post = async (req, res) => {
  try {
    const data = {
      name: req.body.data.name,
    };
    const ownershipType = await prisma.ownershipType.create({ data });
    res
      .status(200)
      .json(ownershipType);
  } catch (error) {
    if (error.code === "P2002")
      return res
        .status(200)
        .json({ statusCode: 0, message: "ownershipType prefix should be unique" });
  }
};

const get = async (req, res) => {
  try {
    const ownershipType = await prisma.ownershipType.findMany({ where: { deleted: 0 } });
    return res.status(200).json(ownershipType);
  } catch (error) {
    console.log("Error: " + error);
  }
};

export default (req, res) => {
  req.method === "POST"
    ? post(req, res)
    : req.method === "PUT"
    ? console.log("PUT")
    : req.method === "DELETE"
    ? console.log("DELETE")
    : req.method === "GET"
    ? get(req, res)
    : res.status(404).send("");
};
