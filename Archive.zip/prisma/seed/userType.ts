export const userType = [
  {
    name: "National Administrator",
    userLevelId: 1,
  },
  {
    name: "National Supervisor",
    userLevelId: 1,
  },
  {
    name: "Regional Administrator",
    userLevelId: 2,
  },
  {
    name: "Regional Supervisor",
    userLevelId: 2,
  },
  {
    name: "MMDA Administrator",
    userLevelId: 3,
  },
  {
    name: "MMDA Supervisor",
    userLevelId: 3,
  },
  {
    name: "MMDA Field Inspector",
    userLevelId: 3,
  },
];
