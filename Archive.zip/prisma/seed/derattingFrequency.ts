export const derattingFrequency = [
    {
      name: "Quarterly",
    },
   
    {
      name: "Half yearly",
    },
    {
      name: "Yearly",
    },
    {
      name: "None",
    },
  
  ];
  








