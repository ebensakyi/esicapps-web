export const unsafeToiletCondition = [
  {
    name: "Defective Containment",
  },
  {
    name: "Exposed Faecal Matter",
  },
  {
    name: "Offensive Odor",
  },
  {
    name: "Leakage",
  },
  {
    name: "Flies Infestation",
  },
];

