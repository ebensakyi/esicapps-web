// export const condition = [
//   {
//     name: "Kept",
//   },
//   {
//     name: "Overgrown",
//   },
// ];
