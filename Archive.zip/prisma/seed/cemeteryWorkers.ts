export const cemeteryWorkers = [
  {
    name: "Sexton",
  },
  {
    name: "Diggers",
  },
  {
    name: "Labourers",
  },
];
