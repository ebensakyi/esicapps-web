export const solidWasteReceptacle = [
    {
      name: "Colour coded bins",
    },
    {
      name: "Covered bins",
    },
    {
        name: "Open bins",
      },
      {
        name: "Polythene bags",
      },
      {
        name: "Sacks",
      },
 
  ];
  

  




