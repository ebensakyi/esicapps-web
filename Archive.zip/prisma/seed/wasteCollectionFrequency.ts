export const wasteFrequency = [
    {
      name: "Daily",
    },
    {
      name: "Weekly",
    },
    {
      name: "Forthnightly",
    },
    {
      name: "Monthly",
    },
    {
      name: "Intermittent",
    }
  ];
  








