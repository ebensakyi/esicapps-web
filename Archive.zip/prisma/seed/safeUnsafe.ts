export const safeUnsafe = [
    {
      name: "Safe",
    },
    {
      name: "Unsafe",
    },
  ];
  