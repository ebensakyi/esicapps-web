export const effluentManagement = [
  {
    name: "Soak pit",
  },
  {
    name: "Drain field",
  },
  {
    name: "Nearby drain",
  },
  {
    name: "Stagnation",
  },
  {
    name: "Water Body",
  }, {
    name: "Open Space",
  },

   
];
