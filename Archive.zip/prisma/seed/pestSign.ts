export const pestSign = [
  {
    name: "Burrows",
  },
  {
    name: "Tracks",
  },
  {
    name: "Droppings",
  },
  {
    name: "Smears",
  },
  {
    name: "Holes",
  },
  {
    name: "Non found",
  },

];
