export const reportType = [
    {
      id: 1,
      name: "Live Report",
    },
    {
      id: 2,
      name: "Late Report",
    },]