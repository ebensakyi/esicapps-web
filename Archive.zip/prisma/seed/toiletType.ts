export const toiletType = [
  {
    name: "WC",
  },
  {
    name: "VIP",
  },
  {
    name: "KVIP",
  },
  {
    name: "Pour Flash",
  },
  {
    name: "Environ Loo",
  },
  {
    name: "Pan Latrine",
  },
  { name: "Pit Latrine" },
];
