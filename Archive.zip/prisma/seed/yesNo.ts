export const yesNo = [
    {
      name: "Yes",
    },
    {
      name: "No",
    },
  ];
  