export const waterFrequency = [
    {
      name: "Regular",
    },
   
    {
      name: "Intermittent",
    }
  ];
  








