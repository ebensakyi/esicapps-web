export const waterTreatmentType = [
  {
    name: "Not Applicable",
  },
  {
    name: "Filtration",
  },
  {
    name: "Boiling",
  },
  { name: "Chlorination" },
  { name: "Reversed Osmosis" },
  { name: "Solar Disinfection" },
];
