export const unservicedWasteDisposal = [
  {
    name: "Crude Dumping",
  },

  {
    name: "Burning",
  },
  {
    name: "Burying",
  },
 
];




