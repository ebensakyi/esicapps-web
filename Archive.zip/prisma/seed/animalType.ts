export const animalType = [
  {
    name: "Dog",
  },
  {
    name: "Cat",
  },
  {
    name: "Sheep",
  },
  {
    name: "Goat",
  },
  {
    name: "Fowl",
  },
  {
    name: "Cattle",
  },
  {
    name: "Pig",
  },
  {
    name: "Rabbit",
  },
  {
    name: "Rat",
  },
  {
    name: "Grasscutter",
  },
  { 
    name: "Other" 
  },
];
