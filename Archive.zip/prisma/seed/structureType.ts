export const structureType = [
  {
    name: "Permanent",
  },
    {
      name: "Temporary",
    },
  
  ];
  