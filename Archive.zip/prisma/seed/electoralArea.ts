export const electoralArea = [
    {
      name: "Dansoman Electoral Area",
      districtId:1
    }
  ];