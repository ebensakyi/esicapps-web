export const excretaDisposalMethod = [
    {
      name: "Mechanical desludging",
    },
    {
      name: "Manual desludging",
    },
    {
      name: "Burying",
    },
    {
      name: "Composting",
    },
   
   
  ];
  
  



