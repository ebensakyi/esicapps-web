export const containerVolume = [
    {
      name: "10 Cubic",
    },
    {
      name: "12 Cubic",
    },
    {
      name: "14 Cubic",
    },
    {
      name: "20 and Above",
    },
  ];
  
