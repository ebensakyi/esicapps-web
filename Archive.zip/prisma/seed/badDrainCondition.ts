export const badDrainCondition = [
  {
    name: "Silted",
  },
  {
    name: "Growth Of Weeds",
  },
  {
    name: "Algae Growth",
  },

];

