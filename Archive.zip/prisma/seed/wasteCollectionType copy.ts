export const wasteCollectionType = [
  {
    name: "Communal container",
  },

  {
    name: "Crude Dumping",
  },
  {
    name: "Burning",
  },
  {
    name: "Burying",
  },
  {
    name: "Tricycle",
  },
];
