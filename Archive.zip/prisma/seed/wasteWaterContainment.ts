export const wasteWaterContainment = [
  {
    name: "Septic tank",
  },
  {
    name: "Holding tank",
  },
  {
    name: "Soak away",
  },
];
