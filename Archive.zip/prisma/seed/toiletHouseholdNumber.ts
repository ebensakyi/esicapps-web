export const toiletHouseholdNumber = [
  {
    name: "Sole Household Usage",
  },
  {
    name: "One other household ",
  },
  {
    name: "Two other households",
  },
  { name: "More than 3 other households" },
];
