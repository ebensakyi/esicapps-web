export const cleaningFrequency = [
    {
      name: "Daily",
    },
    {
      name: "Weekly",
    },
    {
      name: "Monthly",
    },
   
  ];
  







