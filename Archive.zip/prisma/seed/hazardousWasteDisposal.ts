export const hazardousWasteDisposal = [
  {
    name: "Incineration",
  },
  {
    name: "Buried",
  },
  {
    name: "Open burning",
  },
  {
    name: "Accredited Service Provider",
  },
 
];
