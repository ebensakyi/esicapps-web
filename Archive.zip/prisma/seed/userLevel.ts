export const userLevel = [
  {
    name: "National ",
  },
  {
    name: "Regional ",
  },
  {
    name: "District",
  },

];

