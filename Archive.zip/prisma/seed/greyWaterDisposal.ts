export const greyWaterDisposal = [
    {
      name: "Concrete lined drains",
    },
    {
      name: "Earth drain",
    },
    {
        name: "Stagnation",
      },
      {
        name: "Sewage system",
      },
      {
        name: "Soak away",
      },
      {
        name: "Open space disposal",
      },{name: "Holding Tanks"},{name: "Catch pit"}
    
    
  ];
  