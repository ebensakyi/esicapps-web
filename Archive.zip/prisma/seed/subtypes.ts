export const subtypes = [
  {
    name: "Chopbar",
    inspectionFormId: 2,
    typeId: 1,
  },
  {
    name: "Table Top",
    inspectionFormId: 2,
    typeId: 1,
  },
  {
    name: "Fast food",
    inspectionFormId: 2,
    typeId: 1,
  },
  {
    name: "Restaurant",
    inspectionFormId: 2,
    typeId: 1,
  },

  {
    name: "Pub",
    inspectionFormId: 2,
    typeId: 2,
  },
  {
    name: "Lounge",
    inspectionFormId: 2,
    typeId: 2,
  },


 


  {
    name: "Chopbar",
    inspectionFormId: 2,
    typeId: 3,
  },
  {
    name: "Table Top",
    inspectionFormId: 2,
    typeId: 3,
  },
  {
    name: "Fast food",
    inspectionFormId: 2,
    typeId: 3,
  },
  {
    name: "Restaurant",
    inspectionFormId: 2,
    typeId: 3,
  },

  {
    name: "Pub",
    inspectionFormId: 2,
    typeId: 3,
  },
  {
    name: "Lounge",
    inspectionFormId: 2,
    typeId: 3,
  },



  {
    name: "Beverage Producers",
    inspectionFormId: 6,
    typeId: 24,
  },
  {
    name: "Packaged Water Producers",
    inspectionFormId: 6,
    typeId: 24,
  },
  {
    name: "Cold store",
    inspectionFormId: 6,
    typeId: 24,
  },
  {
    name: "Ice cream",
    inspectionFormId: 6,
    typeId: 24,
  },
  {
    name: "Bakery",
    inspectionFormId: 6,
    typeId: 24,
  },
  {
    name: "Meat Shop",
    inspectionFormId: 6,
    typeId: 24,
  },


  {
    name: "Block factory",
    inspectionFormId: 6,
    typeId: 25,
  },
  {
    name: "Construction Company",
    inspectionFormId: 6,
    typeId: 25,
  },
  {
    name: "Oil and Gas Company",
    inspectionFormId: 6,
    typeId: 25,
  },
  {
    name: "Metal Company",
    inspectionFormId: 6,
    typeId: 25,
  },
  {
    name: "Recycling Company",
    inspectionFormId: 6,
    typeId: 25,
  },
  {
    name: "Animal Farms",
    inspectionFormId: 6,
    typeId: 25,
  },
  {
    name: "Shoe Factory",
    inspectionFormId: 6,
    typeId: 25,
  },
  {
    name: "Weave Company",
    inspectionFormId: 6,
    typeId: 25,
  },

  









 


 


  {
    name: "Bulk Water Suppliers",
    inspectionFormId: 6,
    typeId: 26,
  },
  {
    name: "Corn/Fufu Mill",
    inspectionFormId: 6,
    typeId: 26,
  },  {
    name: "Fitting shop",
    inspectionFormId: 6,
    typeId: 26,
  },  {
    name: "Carpentry shop",
    inspectionFormId: 6,
    typeId: 26,
  },  {
    name: "Filling station",
    inspectionFormId: 6,
    typeId: 26,
  },  {
    name: "Electric/Electronic Repairers",
    inspectionFormId: 6,
    typeId: 26,
  },  {
    name: "Salon",
    inspectionFormId: 6,
    typeId: 26,
  },  {
    name: "Washing Bay",
    inspectionFormId: 6,
    typeId: 26,
  },  {
    name: "Fitting shop",
    inspectionFormId: 6,
    typeId: 26,
  },  {
    name: "Fuel station",
    inspectionFormId: 6,
    typeId: 26,
  },  {
    name: "Welding",
    inspectionFormId: 6,
    typeId: 26,
  },  {
    name: "Cosmetic shop",
    inspectionFormId: 6,
    typeId: 26,
  },{
    name: "Tailoring",
    inspectionFormId: 6,
    typeId: 26,
  },{
    name: "Game Centre",
    inspectionFormId: 6,
    typeId: 26,
  },{
    name: "Cinema Hall",
    inspectionFormId: 6,
    typeId: 26,
  },




  {
    name: "School",
    inspectionFormId: 5,
    typeId: 22,
  },
 
  {
    name: "Church",
    inspectionFormId: 5,
    typeId: 21,
  },
  {
    name: "Mosque",
    inspectionFormId: 5,
    typeId: 21,
  },
  {
    name: "Shrine",
    inspectionFormId: 5,
    typeId: 21,
  },
  {
    name: "Financial Institution",
 inspectionFormId: 5,
    typeId: 23,  },
  {
    name: "Companies",
    inspectionFormId: 5,
    typeId: 23,
  },
 


 


  {
    name: "Public toilet",
    inspectionFormId: 8,
    typeId:33
  },{
    name: "Bath house",
    inspectionFormId: 8,
    typeId:33
  },{
    name: "Urinal",
    inspectionFormId: 8,
    typeId:33
  },
];
