export const drinkingWaterSourceType = [
  {
    name: "Pipe-borne",
  },
  {
    name: "Hand dug well with pump",
  },
  {
    name: "Unprotected hand dug well",
  },
  {
    name: "Rain Water",
  },
  {
    name: "River/stream",
  },
  {
    name: "Tanker service",
  },
  {
    name: "Mechanised Borehole",
  },
  {
    name: "Packaged water",
  },
];
