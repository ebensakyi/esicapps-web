export const messageType = [
  {
    name: "Notification",
  },
  {
    name: "SMS",
  },
  {
    name: "Email",
  },
  
];
