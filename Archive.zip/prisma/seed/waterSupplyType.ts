export const waterSupplyType = [
  {
    name: "In-house connection",
  },
  {
    name: "Public stand pipe",
  },
  {
    name: "Tanker service",
  },
  {
    name: "Yard connection",
  },
 

];
