export const inspectionForm = [
  {
    name: "Residential",
  },
  {
    name: "Eatery",
  },
  {
    name: "Health",
  },
  {
    name: "Hospitality",
  },

  {
    name: "Institution",
  },

  {
    name: "Industry",
  },
  {
    name: "Markets & Lorry Parks",
  },
  {
    name: "Sanitary",
  },
];




