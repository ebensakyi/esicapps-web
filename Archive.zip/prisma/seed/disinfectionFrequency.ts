export const disinfectionFrequency = [
  {
    name: "Daily",
  },
    {
      name: "Quarterly",
    },
    {
      name: "Half Yearly",
    },
    {
      name: "Yearly",
    },
    {
      name: "None",
    },
    
  ];
  







