export const unsafeWaterStorage = [
  {
    name: "Evidence Of Siltation",
  },
  {
    name: "No Covering",
  },
  {
    name: "Algae Formation",
  },
  {
    name: "Leakage",
  },
  {
    name: "Unsafe Location",
  },
];
