export const ownershipType = [
    {
      name: "Private",
    },
    {
      name: "Public",
    },
  ];
  