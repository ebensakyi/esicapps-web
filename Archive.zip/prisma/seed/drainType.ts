export const drainType = [
  {
    name: "Concrete lined drains",
  },
  {
    name: "Earth drain",
  },
  {
    name: "Surface flow",
  },
 
];
