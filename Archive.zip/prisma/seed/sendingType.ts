export const sendingType = [
  {
    name: "Single",
  },
  {
    name: "Broadcast",
  },
 
  
];
