export const toiletPitPosition = [
  {
    name: "Direct",
  },
  {
    name: "Offset",
  },
  {
    name: "NA",
  },
];
