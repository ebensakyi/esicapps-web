export const nuisance = [
  {
    id: 1,
    name: "Exposed Excretment",
  },
  {
    id: 2,
    name: "Unsanitary bathroom",
  },
  {
    id: 3,
    name: "Growth of weeds",
  },
  { id: 4, name: "Detrimental accumulation of articles" },
  { id: 5, name: "Insanitary Latrine" },
  { id: 6, name: "Noise" },
  { id: 7, name: "No toilet" },
  { id: 8, name: "Dust" },
  { id: 9, name: "Overcrowding" },
  { id: 10, name: "Accumulation of Refuse" },

  { id: 11, name: "Prohibited animals" },
  { id: 12, name: "Insanitary drains" },
  { id: 13, name: "Insanitary catchpit" },

  { id: 14, name: "Dirty walls of premises" },
  { id: 15, name: "Rats and other vermin" },
  { id: 16, name: "Construction waste" },
  { id: 17, name: "Stagnant waste water" },
  { id: 18, name: "Exposed Faecal matter" },

  { id: 19, name: "Offensive odour" },
  { id: 20, name: "Insanitary Animal Space" },
  { id: 21, name: "Unsafe structure" },
  { id: 22, name: "Stray animals" },
  { id: 23, name: "Dumping and Burning" },
  { id: 24, name: "Insanitary bathroom" },




  { id: 25, name: "Expired Medicine" },
  { id: 26, name: "Exposed food" },

  { id: 27, name: "No Permit" },
  { id: 28, name: "Insanitary kitchen" },

  { id: 29, name: "Defective Placenta Pit" },
  { id: 30, name: "Lack Of Placenta Pit" },


  { id: 31, name: "Defective Containment" },
  { id: 32, name: "Broken Pipe" },
  { id: 33, name: "Defective Tomb" },
  { id: 34, name: "Improper Tomb Layout" },
  { id: 35, name: "Exposed Anal Cleansing Material" },
];
