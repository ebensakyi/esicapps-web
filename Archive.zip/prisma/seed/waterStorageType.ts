export const waterStorageType = [
    {
      name: "Open container",
    },
    {
      name: "Close container",
    },
    {
      name: "Underground reservoir",
    },
    {
      name: "Overhead Reservoir",
    },

  ];
  


