export const toiletDischarge = [
  {
    name: "On-site",
  },
  {
    name: "Off-site",
  },
 
];
