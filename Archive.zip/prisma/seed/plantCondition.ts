export const plantCondition = [
    {
      name: "Kept",
    },
    {
      name: "Overgrown",
    },
  ];
  