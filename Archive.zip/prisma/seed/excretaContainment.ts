export const excretaContainment = [
  {
    name: "Septic tank",
  },
  {
    name: "Holding tank",
  },
  {
    name: "Leach pit",
  },
  {
    name: "Bio-digester",
  },


];
