export const pageActions = [
  {
    name: "Add",
  },
  {
    name: "Update",
  },
  {
    name: "Delete",
  },
  {
    name: "Read",
  },
];
