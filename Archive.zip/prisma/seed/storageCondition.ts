export const storageCondition = [
    {
      name: "",
    },
   
  ];
  