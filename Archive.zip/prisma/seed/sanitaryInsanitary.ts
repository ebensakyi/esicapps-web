export const sanitaryInsanitary = [
    {
      name: "Sanitary",
    },
    {
      name: "Insanitary",
    },
  ];
  