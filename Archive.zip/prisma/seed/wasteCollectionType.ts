export const wasteCollectionType = [
  {
    name: "Communal container",
  },

  {
    name: "Door to door",
  },
  {
    name: "Not serviced",
  },
 
];
