export const waterSourceType = [
  {
    name: "Pipe-borne",
  },
  {
    name: "Protected hand dug well",
  },
  {
    name: "Unprotected hand dug well",
  },
  {
    name: "Rain Water",
  },
  {
    name: "River/stream",
  },
  {
    name: "Tanker service",
  },
  {
    name: "Mechanised Borehole",
  },

];
