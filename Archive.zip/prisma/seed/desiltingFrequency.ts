export const desiltingFrequency = [
  {
    name: "Monthly",
  },
    {
      name: "Quarterly",
    },
   
    {
      name: "Bi yearly",
    },
    {
      name: "Yearly",
    },
    {
      name: "None",
    },
  
  ];








