export const inspectionType = [
  {
    name: "Baseline",
  },
  {
    name: "Reinspection",
  }, {
    name: "Followup",
  },
];
