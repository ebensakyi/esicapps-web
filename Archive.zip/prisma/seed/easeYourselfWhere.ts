export const easeYourselfWhere = [
  {
    name: "Neighbours place",
  },
  {
    name: "Bush",
  },
  {
    name: "Public toilet",
  },
];
