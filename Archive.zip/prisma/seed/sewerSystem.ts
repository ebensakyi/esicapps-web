export const sewerSystem = [
  {
    name: "Centralised",
  },
  {
    name: "Decentralised",
  },
 
];