export const action = [
  {
    name: "Hygiene education",
  },
  {
    name: "Notice served",
  },
  {
    name: "Criminal Summons",
  },
  
];
