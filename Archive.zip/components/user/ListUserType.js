const ListUserType = () => {

  return (
    <div className="row">
    <div className="col-12">
    </div>
  </div>
  )
}


export default ListUserType;
